/**
 * Created by Ivo Meißner on 21.01.18.
 */

const bcrypt = require('bcrypt');

module.exports = function () {
  return bcrypt.hash('password', 1);
};
