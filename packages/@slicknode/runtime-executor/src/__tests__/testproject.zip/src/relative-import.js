/**
 * Created by Ivo Meißner on 21.01.18.
 */

const returnContext = require('./return-context');

module.exports = function (event, context) {
  return returnContext(event, context);
};
