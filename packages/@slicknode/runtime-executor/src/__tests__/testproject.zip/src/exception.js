/**
 * Created by Ivo Meißner on 20.01.18.
 */

module.exports = function () {
  throw new Error('User error message');
};
