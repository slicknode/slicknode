/**
 * Created by Ivo Meißner on 18.01.18.
 */

module.exports = function () {
  return 'Hello world';
};
