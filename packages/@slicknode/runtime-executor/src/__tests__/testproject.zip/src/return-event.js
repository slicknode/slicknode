/**
 * Created by Ivo Meißner on 21.01.18.
 */

module.exports = function (event) {
  return event;
};
