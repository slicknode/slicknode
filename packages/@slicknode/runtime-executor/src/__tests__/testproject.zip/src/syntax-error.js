/**
 * Created by Ivo Meißner on 20.01.18.
 */
/* eslint-disable */

§$%/(&"%§heresome syntax errors